import express from "express";
import fs from "fs";
import bcrypt from "bcrypt";
import cors from "cors";
import bodyParser from "body-parser";
import multer from "multer";
import path from "path";
import { fileURLToPath } from "url";
import realtimejobsRoutes from "./routes/realtimejobs.js";
import operationsRoutes from "./routes/operations.js";
import upcomingjobsRoutes from "./routes/upcomingjobs.js";
import staffRoutes from "./routes/staff.js";
import certRoutes from "./routes/cert.js";
import vendorRoutes from "./routes/vendors.js";
import billingRoutes from "./routes/billing.js";
import inventoryRoutes from "./routes/inventory.js";


const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 5050;

// --- Middleware to protect admin routes ---
const requireAdmin = (req, res, next) => {
  const role = req.headers["x-user-role"];
  if (role === "admin") {
    next();
  } else {
    res.status(403).json({ message: "Forbidden: Admins only" });
  }
};

// --- CORS configuration ---
const allowedOrigins = [
  "http://localhost:5173",
  "http://192.168.0.104:5173" // LAN access
];

app.use(
  cors({
    origin: (origin, callback) => {
      if (!origin || allowedOrigins.includes(origin)) return callback(null, true);
      return callback(new Error("CORS not allowed"));
    },
    methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "x-user-role"],
    credentials: true
  })
);

app.use(bodyParser.json());
app.use("/Staffuploads", express.static(path.join(__dirname, "Staffuploads")));

const uploadDir = path.join(__dirname, "Staffuploads");

// --- Auth file setup ---
const AUTH_FILE = path.join(__dirname, "auth.json");
const AUTH_FILE1 = path.join(__dirname, "auth1.json");

// Utility functions
const readJson = (file) => JSON.parse(fs.readFileSync(file, "utf-8"));
const writeJson = (file, data) =>
  fs.writeFileSync(file, JSON.stringify(data, null, 2), "utf-8");

// Initialize auth file if missing
if (!fs.existsSync(AUTH_FILE)) {
  const defaultHash = bcrypt.hashSync("admin123", 10);
  writeJson(AUTH_FILE, { adminPasswordHash: defaultHash });
}

if (!fs.existsSync(AUTH_FILE1)) {
  const defaultHash = bcrypt.hashSync("admin123", 10);
  writeJson(AUTH_FILE1, { OMPasswordHash: defaultHash }); // ✅ FIXED
}

if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);

app.get("/api/chart1", (req, res) => {
  const imagePath = path.join(__dirname, "data", "Monthly Sales Chart_Chart.png");
  res.sendFile(imagePath);
});

app.get("/api/chart2", (req, res) => {
  const imagePath = path.join(__dirname, "data", "WBSEDCL WorkOrder Chart_Chart.png");
  res.sendFile(imagePath);
});

// Login route
app.post("/api/login", async (req, res) => {
  const { role, password } = req.body;
  if (role !== "admin") return res.json({ success: true });

  const authData = readJson(AUTH_FILE);
  const isMatch = await bcrypt.compare(password, authData.adminPasswordHash);
  if (isMatch) {
    res.json({ success: true });
  } else {
    res.status(401).json({ success: false, message: "Incorrect password" });
  }
});

app.post("/api/login1", async (req, res) => {
  const { role, password } = req.body;
  if (role !== "operationsmanager") return res.json({ success: true });

  const authData = readJson(AUTH_FILE1);
  const isMatch = await bcrypt.compare(password, authData.OMPasswordHash  );
  if (isMatch) {
    res.json({ success: true });
  } else {
    res.status(401).json({ success: false, message: "Incorrect password" });
  }
});

// Change password route
app.post("/api/change-password", async (req, res) => {
  const { oldPassword, newPassword } = req.body;
  if (!oldPassword || !newPassword) {
    return res.status(400).json({ success: false, message: "Missing fields" });
  }

  const authData = readJson(AUTH_FILE);
  const isMatch = await bcrypt.compare(oldPassword, authData.adminPasswordHash);

  if (!isMatch) {
    return res.status(401).json({ success: false, message: "Old password is incorrect" });
  }

  const newHash = await bcrypt.hash(newPassword, 10);
  authData.adminPasswordHash = newHash;
  writeJson(AUTH_FILE, authData);

  res.json({ success: true, message: "Password changed successfully" });
});

app.post("/api/change-password1", async (req, res) => {
  const { oldPassword, newPassword } = req.body;
  if (!oldPassword || !newPassword) {
    return res.status(400).json({ success: false, message: "Missing fields" });
  }

  const authData = readJson(AUTH_FILE1);
  const isMatch = await bcrypt.compare(oldPassword, authData.OMPasswordHash);

  if (!isMatch) {
    return res.status(401).json({ success: false, message: "Old password is incorrect" });
  }

  const newHash = await bcrypt.hash(newPassword, 10);
  authData.OMPasswordHash = newHash;
  writeJson(AUTH_FILE1, authData);

  res.json({ success: true, message: "Password changed successfully" });
});

// --- API Routes ---
app.use("/api/realtimejobs", realtimejobsRoutes);
app.use("/api/inventory", inventoryRoutes);

app.use("/api/operations", requireAdmin, operationsRoutes);
app.use("/api/upcomingjobs", requireAdmin, upcomingjobsRoutes);

app.use("/api/staff", requireAdmin, staffRoutes);


app.use("/api/cert", requireAdmin, certRoutes);
app.use("/api/vendors", requireAdmin, vendorRoutes);
app.use("/api/billing", requireAdmin, billingRoutes);

// --- Health Check ---
app.get("/api/health", (req, res) => {
  res.json({ message: "Server is running" });
});

// --- Start Server ---
app.listen(PORT, "192.168.0.104", () => {
  console.log(`✅ Backend running at http://192.168.0.104:${PORT}`);
});
